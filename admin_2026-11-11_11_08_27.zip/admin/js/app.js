import { api, getToken, getAdmin, clearSession, setUnauthorizedHandler, qs } from "./api.js";
import { html, mount, $, $$, ic, toast, errToast, confirmBox, esc } from "./kit.js";

const app = document.getElementById("app");
const ROUTES = [
  { re: /^\/$/, page: "dashboard", nav: "dash" },
  { re: /^\/orders$/, page: "orders", nav: "orders" },
  { re: /^\/orders\/(\d+)$/, page: "orderDetail", nav: "orders", keys: ["id"] },
  { re: /^\/products$/, page: "products", nav: "products" },
  { re: /^\/products\/new$/, page: "productForm", nav: "products" },
  { re: /^\/products\/(\d+)$/, page: "productForm", nav: "products", keys: ["id"] },
  { re: /^\/categories$/, page: "categories", nav: "categories" },
  { re: /^\/customers$/, page: "customers", nav: "customers", roles: ["owner", "manager"] },
  { re: /^\/customers\/(\d+)$/, page: "customers", nav: "customers", keys: ["id"], roles: ["owner", "manager"] },
  { re: /^\/promos$/, page: "promos", nav: "promos", roles: ["owner", "manager"] },
  { re: /^\/settings$/, page: "settings", nav: "settings" }
];
const NAV = [
  { id: "dash", href: "#/", label: "Dashboard", icon: "dash" },
  { id: "orders", href: "#/orders", label: "Orders", icon: "orders" },
  { id: "products", href: "#/products", label: "Products", icon: "box" },
  { id: "categories", href: "#/categories", label: "Categories", icon: "tag" },
  { id: "customers", href: "#/customers", label: "Customers", icon: "users", roles: ["owner", "manager"] },
  { id: "promos", href: "#/promos", label: "Promo codes", icon: "promo", roles: ["owner", "manager"] },
  { id: "settings", href: "#/settings", label: "Settings", icon: "cog" }
];

let admin = null, token = null, shellReady = false, view = null;
const canSee = (roles) => !roles || roles.includes(admin?.role);

const parseHash = () => {
  const h = location.hash.slice(1) || "/";
  const [path, q = ""] = h.split("?");
  return { path: path.replace(/\/+$/, "") || "/", query: Object.fromEntries(new URLSearchParams(q)) };
};
const isLoginRoute = () => !getToken();

setUnauthorizedHandler(() => { toast("Your session expired. Please log in again.", "err"); showLogin(); });

async function showLogin() {
  shellReady = false; admin = null;
  document.body.classList.remove("nav-open");
  const { renderLogin } = await import("./pages/login.js");
  renderLogin(app, (a) => { admin = a; location.hash = "#/"; boot(); });
}

function shell() {
  mount(app, html`<div class="shell">
    <aside class="side" id="side" aria-label="Main navigation">
      <div class="brand"><img src="/admin/assets/logo-lockup.png" alt="ORIVO" onerror="this.replaceWith(Object.assign(document.createElement('b'),{textContent:'ORIVO'}))"><span>Admin</span></div>
      <nav>${NAV.filter((n) => canSee(n.roles)).map((n) => html`<a href="${n.href}" data-nav="${n.id}">${ic(n.icon, 19)}<span>${n.label}</span>${n.id === "orders" ? html`<span class="n" id="pend" hidden></span>` : ""}</a>`)}</nav>
      <div class="me">
        <div><b>${admin.name}</b><small>${admin.role}</small></div>
        <div class="row"><a class="btn btn-ghost btn-sm" href="/" target="_blank" rel="noopener">${ic("ext", 14)} View store</a>
        <button class="btn btn-ghost btn-sm" id="logout">${ic("logout", 14)} Log out</button></div>
      </div>
    </aside>
    <div class="scrim" id="scrim"></div>
    <div class="main">
      <header class="topbar"><button class="icon-btn" id="burger" aria-label="Open menu" aria-controls="side" aria-expanded="false">${ic("menu", 22)}</button>
        <img src="/admin/assets/logo-lockup.png" alt="ORIVO"><span class="muted" id="ttl"></span></header>
      <main class="page" id="view" tabindex="-1"></main>
    </div></div>`);
  view = $("#view");
  const burger = $("#burger");
  const setNav = (open) => { document.body.classList.toggle("nav-open", open); burger.setAttribute("aria-expanded", String(open)); };
  burger.addEventListener("click", () => setNav(!document.body.classList.contains("nav-open")));
  $("#scrim").addEventListener("click", () => setNav(false));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") setNav(false); });
  $$(".side nav a").forEach((a) => a.addEventListener("click", () => setNav(false)));
  $("#logout").addEventListener("click", async () => {
    if (await confirmBox({ title: "Log out?", message: "You will need to sign in again to manage the store.", confirmText: "Log out" })) { clearSession(); showLogin(); }
  });
  shellReady = true;
}

async function refreshBadge() {
  try {
    const r = await api.get("/orders" + qs({ status: "pending", limit: 1 }));
    const b = $("#pend"); if (!b) return;
    b.textContent = r.total > 99 ? "99+" : r.total; b.hidden = !r.total;
  } catch (e) { /* non-critical */ }
}

let seq = 0;
async function dispatch() {
  if (isLoginRoute()) return showLogin();
  if (!shellReady) return;
  const { path, query } = parseHash();
  let match = null, params = {};
  for (const r of ROUTES) {
    const m = r.re.exec(path);
    if (m) { match = r; (r.keys || []).forEach((k, i) => (params[k] = m[i + 1])); break; }
  }
  const my = ++seq;
  const alive = () => my === seq;
  if (!match) { mount(view, html`<div class="empty"><b>Page not found</b><a class="link" href="#/">Back to dashboard</a></div>`); return; }
  if (!canSee(match.roles)) { mount(view, html`<div class="empty"><b>No access</b>Your role (${admin.role}) can't open this page.<br><a class="link" href="#/">Back to dashboard</a></div>`); return; }
  $$(".side nav a").forEach((a) => a.classList.toggle("on", a.dataset.nav === match.nav));
  const label = NAV.find((n) => n.id === match.nav)?.label || "";
  $("#ttl").textContent = label; document.title = `${label} · ORIVO Admin`;
  mount(view, html`<div class="skeleton" style="height:34px;width:220px;margin-bottom:22px"></div><div class="skeleton" style="height:320px"></div>`);
  try {
    const mod = await import(`./pages/${match.page}.js`);
    if (!alive()) return;
    view.innerHTML = "";
    const ctx = {
      admin, alive,
      go: (to) => { location.hash = to; },
      setQuery: (o) => { history.replaceState(null, "", "#" + path + qs(o)); },
      refreshBadge
    };
    await mod.default(view, params, query, ctx);
    if (alive()) { scrollTo(0, 0); refreshBadge(); }
  } catch (e) {
    if (!alive()) return;
    console.error(e);
    mount(view, html`<div class="empty"><b>Couldn't load this page</b>${e.message}<div class="mt"><button class="btn btn-ghost" id="retry">Try again</button></div></div>`);
    $("#retry")?.addEventListener("click", dispatch);
  }
}

async function boot() {
  if (!getToken()) return showLogin();
  admin = admin || getAdmin();
  if (!admin) { clearSession(); return showLogin(); }
  shell();
  dispatch();
}

addEventListener("hashchange", () => { document.body.classList.remove("nav-open"); dispatch(); });
boot();
