// Shared admin UI helpers: icons, pills, modals, pager, skeletons.
import { html, raw, esc, $, $$, mount, toast as baseToast } from "/js/ui.js";
export { html, raw, esc, $, $$, mount };
export { money, fmtDate, fmtDateTime } from "/js/ui.js";

const P = {
  dash: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  orders: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  box: '<path d="m3 7 9-4 9 4v10l-9 4-9-4z"/><path d="m3 7 9 4 9-4M12 11v10"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.3"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.3-5.5 6.5-5.5s5.7 2 6.5 5.5M16 4.8a3.5 3.5 0 0 1 0 6.4M18.5 14.8c1.7.7 2.7 2.4 3 5.2"/>',
  promo: '<path d="M20 12 12 20 4 12V4h8z" transform="rotate(0)"/><path d="m9 9 6 6M9.5 14.5h.01M14.5 9.5h.01"/>',
  cog: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/>',
  logout: '<path d="M9 4H5v16h4M16 8l4 4-4 4M20 12H9"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  up: '<path d="M12 19V5M6 11l6-6 6 6"/>', left: '<path d="M19 12H5M11 6l-6 6 6 6"/>', right: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  chevl: '<path d="m15 5-7 7 7 7"/>', chevr: '<path d="m9 5 7 7-7 7"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
  print: '<path d="M7 9V3h10v6M7 17H4v-7h16v7h-3"/><rect x="7" y="14" width="10" height="7"/>',
  phone: '<path d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2z"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.01"/>',
  img: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-8 8"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7"/>', warn: '<path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17v.01"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>', ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v5H5V6h5"/>'
};
export const ic = (name, size = 18) => raw(`<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name] || P.info}</svg>`);

export const toast = (m, k = "") => baseToast(m, k);
export const errToast = (e) => baseToast(e && e.message ? e.message : "Something went wrong", "err");

const LABEL = { pending: "Pending", confirmed: "Confirmed", processing: "Processing", shipped: "Shipped", delivered: "Delivered", cancelled: "Cancelled",
  paid: "Paid", failed: "Failed", refunded: "Refunded", active: "Active", inactive: "Inactive", draft: "Draft" };
export const pill = (s, label) => html`<span class="pill st-${s}">${label || LABEL[s] || s}</span>`;
export const PAY_LABEL = { cod: "Cash on delivery", bkash: "bKash", nagad: "Nagad", rocket: "Rocket", card: "Card" };
export const payLabel = (m) => PAY_LABEL[m] || m || "—";

export const debounce = (fn, ms = 350) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
export const thumb = (url, alt = "") => url ? html`<div class="thumb"><img src="${url}" alt="${alt}" loading="lazy"></div>` : html`<div class="thumb">${ic("img", 20)}</div>`;

export const skeletonRows = (n = 6) => html`<div style="padding:16px;display:grid;gap:12px">${Array.from({ length: n }, () => html`<div class="skeleton" style="height:42px"></div>`)}</div>`;
export const emptyState = (title, text = "") => html`<div class="empty"><b>${title}</b>${text}</div>`;

/** Render prev/next pager into container. cb(page). */
export function pager(el, { page, pages, total }, cb, noun = "results") {
  if (!total && total !== 0) { el.innerHTML = ""; return; }
  mount(el, html`<div class="pager"><span>${total} ${noun}${pages > 1 ? ` · page ${page} of ${pages}` : ""}</span>
    ${pages > 1 ? html`<div class="btns"><button class="btn btn-ghost btn-sm" data-p="${page - 1}" ${page <= 1 ? "disabled" : ""} aria-label="Previous page">${ic("chevl", 14)} Prev</button>
    <button class="btn btn-ghost btn-sm" data-p="${page + 1}" ${page >= pages ? "disabled" : ""} aria-label="Next page">Next ${ic("chevr", 14)}</button></div>` : ""}</div>`);
  $$("[data-p]", el).forEach((b) => b.addEventListener("click", () => cb(Number(b.dataset.p))));
}

/** Run an async fn while a button is disabled. Errors become toasts. Returns result or undefined on failure. */
export async function busy(btn, fn) {
  if (btn) { btn.disabled = true; btn.dataset.t = btn.innerHTML; }
  try { return await fn(); }
  catch (e) { errToast(e); }
  finally { if (btn && btn.isConnected) { btn.disabled = false; } }
}

/* ───── modal with focus management ───── */
let openCount = 0;
export function modal({ title, body, footer = "", wide = false, onMount, label }) {
  const prev = document.activeElement;
  const back = document.createElement("div");
  back.className = "modal-back";
  const id = "m" + Math.random().toString(36).slice(2, 7);
  back.innerHTML = `<div class="modal ${wide ? "wide" : ""}" role="dialog" aria-modal="true" aria-labelledby="${id}">
    <header><h2 id="${id}">${esc(title)}</h2><button class="icon-btn" data-x aria-label="Close dialog">${ic("x").__raw}</button></header>
    <div class="body">${body && body.__raw !== undefined ? body.__raw : esc(body || "")}</div>${footer ? `<footer>${footer.__raw !== undefined ? footer.__raw : footer}</footer>` : ""}</div>`;
  document.body.append(back);
  openCount++; document.body.style.overflow = "hidden";
  const box = back.querySelector(".modal");
  let closed = false;
  const close = (result) => {
    if (closed) return; closed = true;
    document.removeEventListener("keydown", key, true);
    back.remove(); if (--openCount <= 0) { openCount = 0; document.body.style.overflow = ""; }
    if (prev && prev.focus && prev.isConnected) prev.focus();
    api.resolve && api.resolve(result);
  };
  const focusables = () => [...box.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')].filter((e) => e.offsetParent !== null);
  function key(e) {
    if (e.key === "Escape") { e.stopPropagation(); close(undefined); }
    else if (e.key === "Tab") {
      const f = focusables(); if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  }
  document.addEventListener("keydown", key, true);
  back.addEventListener("mousedown", (e) => { if (e.target === back) close(undefined); });
  back.querySelector("[data-x]").addEventListener("click", () => close(undefined));
  back.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => close(undefined)));
  const api = {};
  const promise = new Promise((r) => { api.resolve = r; });
  const ctl = { el: box, close, closed: promise };
  setTimeout(() => { const f = box.querySelector("[autofocus],input:not([type=hidden]),select,textarea") || focusables().pop(); if (f) f.focus(); }, 30);
  if (onMount) onMount(box, close);
  return ctl;
}

export function confirmBox({ title = "Are you sure?", message = "", confirmText = "Confirm", danger = false }) {
  return new Promise((resolve) => {
    const m = modal({
      title, body: html`<p class="muted">${message}</p>`,
      footer: html`<button class="btn btn-ghost" data-close>Cancel</button><button class="btn ${danger ? "btn-danger" : "btn-primary"}" data-ok>${confirmText}</button>`,
      onMount: (box, close) => { box.querySelector("[data-ok]").addEventListener("click", () => { close(true); }); box.querySelector("[data-ok]").focus(); }
    });
    m.closed.then((r) => resolve(r === true));
  });
}

/** Read a form into a plain object (checkboxes => boolean). */
export function formData(form) {
  const o = {};
  for (const el of form.elements) {
    if (!el.name || el.disabled) continue;
    if (el.type === "checkbox") o[el.name] = el.checked;
    else if (el.type === "radio") { if (el.checked) o[el.name] = el.value; }
    else o[el.name] = el.value;
  }
  return o;
}

/** datetime-local string from a DB timestamp (local time). */
export function toLocalInput(v) {
  if (!v) return "";
  const d = new Date(v); if (isNaN(d)) return "";
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}
/** DATE column -> YYYY-MM-DD without timezone drift when a Date was serialised. */
export function dateOnly(v) {
  if (!v) return "";
  const s = String(v);
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const d = new Date(s); if (isNaN(d)) return s.slice(0, 10);
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
