import { api, qs } from "../api.js";
import { html, mount, $, $$, money, fmtDate, ic, pill, thumb, pager, debounce, skeletonRows, emptyState, errToast, toast, confirmBox, busy, dateOnly } from "../kit.js";

export default async function (el, params, query, ctx) {
  const f = { q: query.q || "", status: query.status || "", availability: query.availability || "", type: query.type || "", category: query.category || "", low: query.low === "1", page: Number(query.page) || 1 };
  let cats = [];
  try { cats = (await api.get("/categories")).categories; } catch (e) { /* filter just stays empty */ }
  if (!ctx.alive()) return;
  const parents = cats.filter((c) => !c.parent_id);
  mount(el, html`<div class="page-head"><div><h1>Products</h1><p>Everything in your catalogue, in stock and coming soon.</p></div>
      <div class="actions"><a class="btn btn-primary" href="#/products/new">${ic("plus")} Add product</a></div></div>
    <div class="filters" role="search">
      <input class="q" type="search" id="q" placeholder="Search name or SKU…" aria-label="Search products" value="${f.q}">
      <select id="availability" aria-label="Section"><option value="">All sections</option><option value="available" ${f.availability === "available" ? "selected" : ""}>Available</option><option value="preorder" ${f.availability === "preorder" ? "selected" : ""}>Pre-order</option></select>
      <select id="status" aria-label="Status"><option value="">Any status</option>${["active", "inactive", "draft"].map((s) => html`<option value="${s}" ${f.status === s ? "selected" : ""}>${s[0].toUpperCase() + s.slice(1)}</option>`)}</select>
      <select id="type" aria-label="Type"><option value="">Physical + digital</option><option value="physical" ${f.type === "physical" ? "selected" : ""}>Physical</option><option value="digital" ${f.type === "digital" ? "selected" : ""}>Digital</option></select>
      <select id="category" aria-label="Category"><option value="">All categories</option>${parents.map((p) => html`<option value="${p.id}" ${String(f.category) === String(p.id) ? "selected" : ""}>${p.name} (all)</option>${cats.filter((c) => c.parent_id === p.id).map((c) => html`<option value="${c.id}" ${String(f.category) === String(c.id) ? "selected" : ""}>— ${c.name}</option>`)}`)}</select>
      <label class="chip-toggle"><input type="checkbox" id="low" ${f.low ? "checked" : ""}>Low stock</label>
    </div>
    <div class="card flush"><div id="tbl" aria-live="polite"></div><div id="pg"></div></div>`);

  let reqId = 0;
  async function load() {
    const my = ++reqId;
    ctx.setQuery({ ...f, page: f.page > 1 ? f.page : "" });
    mount($("#tbl"), skeletonRows(8));
    let r;
    try { r = await api.get("/products" + qs({ ...f, limit: 20 })); }
    catch (e) { if (my !== reqId || !ctx.alive()) return; errToast(e); mount($("#tbl"), emptyState("Couldn't load products", e.message)); return; }
    if (my !== reqId || !ctx.alive()) return;
    if (!r.products.length) { mount($("#tbl"), emptyState("No products found", "Try different filters, or add your first product.")); $("#pg").innerHTML = ""; return; }
    mount($("#tbl"), html`<div class="table-wrap"><table class="cards"><thead><tr><th>Product</th><th>Section</th><th class="num">Price</th><th class="num">Stock</th><th>Status</th><th>Featured</th><th></th></tr></thead><tbody>
      ${r.products.map((p) => {
        const stocked = p.product_type === "physical" && p.availability === "available" && p.track_stock;
        return html`<tr data-id="${p.id}">
        <td class="main-cell"><div class="cell-prod">${thumb(p.image, p.name)}<div><a href="#/products/${p.id}"><b>${p.name}</b></a>
          <span class="sub">${[p.sku, p.category_name].filter(Boolean).join(" · ")}${p.product_type === "digital" ? " · Digital" : ""}</span></div></div></td>
        <td data-l="Section">${p.availability === "preorder" ? html`<span class="tag pre">Pre-order</span>${p.preorder_date ? html`<span class="sub">${fmtDate(dateOnly(p.preorder_date))}</span>` : ""}` : html`<span class="tag">Available</span>`}</td>
        <td class="num" data-l="Price">${p.sale_price && Number(p.sale_price) < Number(p.regular_price) ? html`<b>${money(p.sale_price)}</b><span class="sub"><s>${money(p.regular_price)}</s></span>` : html`<b>${money(p.regular_price)}</b>`}</td>
        <td class="num" data-l="Stock">${stocked ? html`<input class="inline-num" type="number" min="0" value="${p.stock_quantity}" data-stock="${p.id}" aria-label="Stock for ${p.name}">` : html`<span class="faint">—</span>`}</td>
        <td data-l="Status"><select data-status="${p.id}" aria-label="Status for ${p.name}" style="width:auto;padding:5px 30px 5px 10px">${["active", "inactive", "draft"].map((s) => html`<option value="${s}" ${p.status === s ? "selected" : ""}>${s[0].toUpperCase() + s.slice(1)}</option>`)}</select></td>
        <td data-l="Featured"><label class="switch"><input type="checkbox" data-feat="${p.id}" ${p.featured ? "checked" : ""} aria-label="Featured: ${p.name}"><i></i></label></td>
        <td class="act right nowrap"><a class="icon-btn" href="#/products/${p.id}" aria-label="Edit ${p.name}" style="display:inline-grid">${ic("edit")}</a>
          <button class="icon-btn" data-del="${p.id}" data-name="${p.name}" aria-label="Delete ${p.name}">${ic("trash")}</button></td></tr>`; })}</tbody></table></div>`);
    pager($("#pg"), r, (p) => { f.page = p; load(); scrollTo({ top: 0 }); }, "products");
    const tbl = $("#tbl");
    $$("[data-status]", tbl).forEach((s) => s.addEventListener("change", async () => { s.disabled = true; try { await api.patch("/products/" + s.dataset.status, { status: s.value }); toast("Status updated"); } catch (e) { errToast(e); load(); } s.disabled = false; }));
    $$("[data-feat]", tbl).forEach((s) => s.addEventListener("change", async () => { try { await api.patch("/products/" + s.dataset.feat, { featured: s.checked }); toast(s.checked ? "Marked as featured" : "Removed from featured"); } catch (e) { s.checked = !s.checked; errToast(e); } }));
    $$("[data-stock]", tbl).forEach((s) => {
      const orig = s.value;
      s.addEventListener("change", async () => {
        const v = Math.max(0, parseInt(s.value, 10) || 0); s.value = v;
        try { await api.patch("/products/" + s.dataset.stock, { stock_quantity: v }); s.defaultValue = v; toast("Stock updated"); } catch (e) { s.value = s.defaultValue || orig; errToast(e); }
      });
    });
    $$("[data-del]", tbl).forEach((b) => b.addEventListener("click", async () => {
      if (!(await confirmBox({ title: "Delete product?", danger: true, confirmText: "Delete", message: `"${b.dataset.name}" will be removed from the store. Past orders keep their own copy of the item. This can't be undone. (Tip: set it to Inactive to just hide it.)` }))) return;
      try { await api.del("/products/" + b.dataset.del); toast("Product deleted"); load(); } catch (e) { errToast(e); }
    }));
  }
  const reset = () => { f.page = 1; load(); };
  $("#q").addEventListener("input", debounce((e) => { f.q = e.target.value.trim(); reset(); }));
  ["availability", "status", "type", "category"].forEach((k) => $("#" + k).addEventListener("change", (e) => { f[k] = e.target.value; reset(); }));
  $("#low").addEventListener("change", (e) => { f.low = e.target.checked; reset(); });
  load();
}
