import { api, setSession } from "../api.js";
import { html, mount, $, ic } from "../kit.js";

export function renderLogin(root, onSuccess) {
  document.title = "Log in · ORIVO Admin";
  mount(root, html`<div class="login"><div class="box">
    <img src="/admin/assets/logo-lockup.png" alt="ORIVO">
    <form class="card" id="f" novalidate>
      <h1>Admin sign in</h1><p class="muted" style="margin-bottom:20px">Manage products, orders and customers.</p>
      <div class="notice err" id="err" role="alert" hidden style="margin-bottom:14px"></div>
      <div class="field"><label for="em">Email</label><input id="em" name="email" type="email" autocomplete="username" required autofocus></div>
      <div class="field"><label for="pw">Password</label><input id="pw" name="password" type="password" autocomplete="current-password" required></div>
      <button class="btn btn-primary btn-block" id="go" type="submit" style="margin-top:6px;padding:12px">Sign in</button>
    </form>
    <p class="faint" style="margin-top:18px;font-size:12px">ORIVO · Own the Look. Own the Moment.</p>
  </div></div>`);
  const f = $("#f"), err = $("#err"), go = $("#go");
  f.addEventListener("submit", async (e) => {
    e.preventDefault();
    err.hidden = true;
    const email = f.email.value.trim(), password = f.password.value;
    if (!email || !password) { err.textContent = "Enter your email and password."; err.hidden = false; return; }
    go.disabled = true; go.textContent = "Signing in…";
    try {
      const r = await api.login(email, password);
      setSession(r.token, r.admin);
      onSuccess(r.admin);
    } catch (ex) {
      err.textContent = ex.message; err.hidden = false;
      go.disabled = false; go.textContent = "Sign in"; f.password.select();
    }
  });
}
