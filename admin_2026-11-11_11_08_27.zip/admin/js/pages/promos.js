import { api } from "../api.js";
import { html, mount, $, $$, money, fmtDate, ic, pill, modal, confirmBox, toast, errToast, busy, formData, skeletonRows, emptyState, toLocalInput } from "../kit.js";

const APPLIES = { all: "All items", available: "Available items", preorder: "Pre-order items" };

export default async function (el, params, query, ctx) {
  mount(el, html`<div class="page-head"><div><h1>Promo codes</h1><p>Discounts for ORIVO members.</p></div><div class="actions"><button class="btn btn-primary" id="add">${ic("plus")} New promo code</button></div></div>
    <div class="notice ice" style="margin-bottom:16px">${ic("info")}<span>Promo codes only work for customers who are <b>logged in to an ORIVO account</b>. Guest checkout customers see a prompt to log in or sign up when they try a code.</span></div>
    <div class="card flush"><div id="tbl" aria-live="polite"></div></div>`);
  let promos = [];
  async function load() {
    mount($("#tbl"), skeletonRows(5));
    try { promos = (await api.get("/promos")).promos; } catch (e) { if (!ctx.alive()) return; errToast(e); mount($("#tbl"), emptyState("Couldn't load promo codes", e.message)); return; }
    if (!ctx.alive()) return; draw();
  }
  const state = (p) => {
    const now = new Date();
    if (!p.is_active) return ["inactive", "Off"];
    if (p.expires_at && new Date(p.expires_at) < now) return ["cancelled", "Expired"];
    if (p.starts_at && new Date(p.starts_at) > now) return ["pending", "Scheduled"];
    if (p.usage_limit && p.used_count >= p.usage_limit) return ["cancelled", "Used up"];
    return ["active", "Live"];
  };
  function draw() {
    if (!promos.length) { mount($("#tbl"), emptyState("No promo codes yet", "Create one to reward your members.")); return; }
    mount($("#tbl"), html`<div class="table-wrap"><table class="cards"><thead><tr><th>Code</th><th>Discount</th><th>Applies to</th><th class="num">Used</th><th>Valid</th><th>Status</th><th>On</th><th></th></tr></thead><tbody>
      ${promos.map((p) => { const [s, sl] = state(p); return html`<tr><td class="main-cell"><b style="letter-spacing:.06em">${p.code}</b>${p.description ? html`<span class="sub">${p.description}</span>` : ""}</td>
        <td data-l="Discount">${p.discount_type === "percent" ? Number(p.discount_value) + "%" : money(p.discount_value)}${Number(p.min_order_amount) ? html`<span class="sub">min ${money(p.min_order_amount)}${p.max_discount_amount ? ` · max ${money(p.max_discount_amount)}` : ""}</span>` : p.max_discount_amount ? html`<span class="sub">max ${money(p.max_discount_amount)}</span>` : ""}</td>
        <td data-l="Applies to">${p.applies_to === "preorder" ? html`<span class="tag pre">Pre-order</span>` : html`<span class="tag">${APPLIES[p.applies_to]}</span>`}</td>
        <td class="num" data-l="Used">${p.used_count}${p.usage_limit ? " / " + p.usage_limit : ""}<span class="sub">${p.per_customer_limit}× per customer</span></td>
        <td data-l="Valid" class="nowrap">${p.starts_at || p.expires_at ? html`${p.starts_at ? fmtDate(p.starts_at) : "Now"} → ${p.expires_at ? fmtDate(p.expires_at) : "No end"}` : html`<span class="faint">Always</span>`}</td>
        <td data-l="Status">${pill(s, sl)}</td>
        <td data-l="On"><label class="switch"><input type="checkbox" data-on="${p.id}" ${p.is_active ? "checked" : ""} aria-label="Active: ${p.code}"><i></i></label></td>
        <td class="act right nowrap"><button class="icon-btn" data-edit="${p.id}" aria-label="Edit ${p.code}">${ic("edit")}</button><button class="icon-btn" data-del="${p.id}" aria-label="Delete ${p.code}">${ic("trash")}</button></td></tr>`; })}</tbody></table></div>`);
    $$("[data-edit]").forEach((b) => b.addEventListener("click", () => edit(promos.find((p) => p.id === Number(b.dataset.edit)))));
    $$("[data-on]").forEach((s) => s.addEventListener("change", async () => {
      const p = promos.find((x) => x.id === Number(s.dataset.on));
      try { await api.put("/promos/" + p.id, body(p, { is_active: s.checked })); toast(s.checked ? "Promo activated" : "Promo switched off"); load(); } catch (e) { s.checked = !s.checked; errToast(e); }
    }));
    $$("[data-del]").forEach((b) => b.addEventListener("click", async () => {
      const p = promos.find((x) => x.id === Number(b.dataset.del));
      if (!(await confirmBox({ title: "Delete promo code?", danger: true, confirmText: "Delete", message: `${p.code} will stop working immediately. Orders that already used it keep their discount.` }))) return;
      try { await api.del("/promos/" + p.id); toast("Promo code deleted"); load(); } catch (e) { errToast(e); }
    }));
  }
  // payload from an existing row (used by the quick on/off switch)
  const body = (p, o = {}) => ({ code: p.code, description: p.description || "", discount_type: p.discount_type, discount_value: p.discount_value, min_order_amount: p.min_order_amount, max_discount_amount: p.max_discount_amount,
    usage_limit: p.usage_limit, per_customer_limit: p.per_customer_limit, applies_to: p.applies_to, starts_at: toLocalInput(p.starts_at), expires_at: toLocalInput(p.expires_at), is_active: !!p.is_active, ...o });

  function edit(p) {
    const isNew = !p;
    p = p || { code: "", description: "", discount_type: "percent", discount_value: "", min_order_amount: 0, max_discount_amount: "", usage_limit: "", per_customer_limit: 1, applies_to: "all", starts_at: "", expires_at: "", is_active: 1 };
    modal({
      title: isNew ? "New promo code" : "Edit promo code", wide: true,
      body: html`<form id="pform" novalidate>
        <div class="grid2"><div class="field"><label for="p-code">Code *</label><input id="p-code" name="code" required maxlength="40" value="${p.code}" style="text-transform:uppercase;letter-spacing:.06em" placeholder="WELCOME10"><span class="hint">3–40 letters, numbers, - or _</span></div>
          <div class="field"><label for="p-desc">Description</label><input id="p-desc" name="description" maxlength="255" value="${p.description || ""}" placeholder="Shown to the customer"></div></div>
        <div class="grid3"><div class="field"><label for="p-type">Discount type</label><select id="p-type" name="discount_type"><option value="percent" ${p.discount_type === "percent" ? "selected" : ""}>Percent (%)</option><option value="fixed" ${p.discount_type === "fixed" ? "selected" : ""}>Fixed amount (৳)</option></select></div>
          <div class="field"><label for="p-val">Value *</label><input id="p-val" name="discount_value" type="number" min="0" step="0.01" required value="${p.discount_value}"></div>
          <div class="field"><label for="p-max">Max discount (৳)</label><input id="p-max" name="max_discount_amount" type="number" min="0" step="0.01" value="${p.max_discount_amount ?? ""}" placeholder="No cap"></div></div>
        <div class="grid3"><div class="field"><label for="p-min">Minimum order (৳)</label><input id="p-min" name="min_order_amount" type="number" min="0" step="0.01" value="${p.min_order_amount ?? 0}"></div>
          <div class="field"><label for="p-lim">Total uses</label><input id="p-lim" name="usage_limit" type="number" min="0" step="1" value="${p.usage_limit ?? ""}" placeholder="Unlimited"></div>
          <div class="field"><label for="p-pc">Uses per customer</label><input id="p-pc" name="per_customer_limit" type="number" min="1" step="1" value="${p.per_customer_limit || 1}"></div></div>
        <div class="field"><label for="p-ap">Applies to</label><select id="p-ap" name="applies_to">${Object.entries(APPLIES).map(([k, l]) => html`<option value="${k}" ${p.applies_to === k ? "selected" : ""}>${l}</option>`)}</select></div>
        <div class="grid2"><div class="field"><label for="p-st">Starts</label><input id="p-st" name="starts_at" type="datetime-local" value="${toLocalInput(p.starts_at)}"></div>
          <div class="field"><label for="p-ex">Expires</label><input id="p-ex" name="expires_at" type="datetime-local" value="${toLocalInput(p.expires_at)}"></div></div>
        <label class="check"><span class="switch"><input type="checkbox" name="is_active" ${p.is_active ? "checked" : ""}><i></i></span>Active</label>
        <div class="notice ice mt">${ic("info")}<span>Members only: guests can't use promo codes.</span></div></form>`,
      footer: html`<button class="btn btn-ghost" data-close>Cancel</button><button class="btn btn-primary" id="p-save">${isNew ? "Create code" : "Save changes"}</button>`,
      onMount(box, close) {
        const typeSel = $("#p-type", box), val = $("#p-val", box);
        const syncType = () => { val.max = typeSel.value === "percent" ? 100 : ""; };
        typeSel.addEventListener("change", syncType); syncType();
        const save = $("#p-save", box);
        const submit = async () => {
          const d = formData($("#pform", box)); d.code = d.code.trim().toUpperCase();
          if (!/^[A-Z0-9_-]{3,40}$/.test(d.code)) { toast("Code must be 3–40 letters, numbers, - or _", "err"); return; }
          if (!(parseFloat(d.discount_value) > 0)) { toast("Discount value must be greater than 0", "err"); return; }
          if (d.discount_type === "percent" && parseFloat(d.discount_value) > 100) { toast("Percent discount can't exceed 100", "err"); return; }
          if (d.starts_at && d.expires_at && new Date(d.expires_at) <= new Date(d.starts_at)) { toast("Expiry must be after the start date", "err"); return; }
          const r = await busy(save, () => (isNew ? api.post("/promos", d) : api.put("/promos/" + p.id, d)));
          if (r) { toast(isNew ? "Promo code created" : "Promo code saved"); close(); load(); }
        };
        save.addEventListener("click", submit);
        $("#pform", box).addEventListener("submit", (e) => { e.preventDefault(); submit(); });
      }
    });
  }
  $("#add").addEventListener("click", () => edit(null));
  load();
}
