import { api } from "../api.js";
import { html, mount, $, $$, ic, pill, thumb, modal, confirmBox, toast, errToast, busy, formData, skeletonRows, emptyState } from "../kit.js";

export default async function (el, params, query, ctx) {
  mount(el, html`<div class="page-head"><div><h1>Categories</h1><p>Group products into departments. Categories can sit one level deep (e.g. Women → Bags).</p></div>
    <div class="actions"><button class="btn btn-primary" id="add">${ic("plus")} Add category</button></div></div>
    <div class="card flush"><div id="tbl" aria-live="polite"></div></div>`);
  let cats = [];
  async function load() {
    mount($("#tbl"), skeletonRows(7));
    try { cats = (await api.get("/categories")).categories; } catch (e) { if (!ctx.alive()) return; errToast(e); mount($("#tbl"), emptyState("Couldn't load categories", e.message)); return; }
    if (!ctx.alive()) return;
    draw();
  }
  function draw() {
    if (!cats.length) { mount($("#tbl"), emptyState("No categories yet", "Add your first category to organise the store.")); return; }
    const sorted = cats.filter((c) => !c.parent_id).sort((a, b) => a.sort_order - b.sort_order || a.id - b.id);
    const rows = [];
    for (const p of sorted) {
      rows.push([p, false]);
      cats.filter((c) => c.parent_id === p.id).sort((a, b) => a.sort_order - b.sort_order || a.id - b.id).forEach((c) => rows.push([c, true]));
    }
    // orphans (parent missing) still show
    cats.filter((c) => c.parent_id && !cats.some((x) => x.id === c.parent_id)).forEach((c) => rows.push([c, true]));
    mount($("#tbl"), html`<div class="table-wrap"><table class="cards"><thead><tr><th>Name</th><th>Slug</th><th class="num">Products</th><th class="num">Order</th><th>Status</th><th></th></tr></thead><tbody>
      ${rows.map(([c, child]) => html`<tr class="${child ? "cat-child" : "cat-row"}"><td class="main-cell">${c.name}${c.description ? html`<span class="sub">${c.description}</span>` : ""}</td>
        <td data-l="Slug" class="faint">${c.slug}</td><td class="num" data-l="Products">${c.product_count}</td><td class="num" data-l="Order">${c.sort_order}</td>
        <td data-l="Status">${pill(c.is_active ? "active" : "inactive")}</td>
        <td class="act right nowrap"><button class="icon-btn" data-edit="${c.id}" aria-label="Edit ${c.name}">${ic("edit")}</button><button class="icon-btn" data-del="${c.id}" aria-label="Delete ${c.name}">${ic("trash")}</button></td></tr>`)}</tbody></table></div>`);
    $$("[data-edit]").forEach((b) => b.addEventListener("click", () => edit(cats.find((c) => c.id === Number(b.dataset.edit)))));
    $$("[data-del]").forEach((b) => b.addEventListener("click", async () => {
      const c = cats.find((x) => x.id === Number(b.dataset.del));
      if (!(await confirmBox({ title: "Delete category?", danger: true, confirmText: "Delete", message: `"${c.name}" will be deleted. Categories with sub-categories or products can't be deleted; hide them instead.` }))) return;
      try { await api.del("/categories/" + c.id); toast("Category deleted"); load(); } catch (e) { errToast(e); }
    }));
  }

  function edit(c) {
    const isNew = !c; c = c || { name: "", slug: "", parent_id: "", description: "", image_url: "", sort_order: 0, is_active: 1 };
    const hasKids = !isNew && cats.some((x) => x.parent_id === c.id);
    const parents = cats.filter((x) => !x.parent_id && x.id !== c.id);
    let image = c.image_url || "";
    const m = modal({
      title: isNew ? "Add category" : "Edit category",
      body: html`<form id="cf" novalidate>
        <div class="field"><label for="c-name">Name *</label><input id="c-name" name="name" required maxlength="120" value="${c.name}"></div>
        <div class="grid2"><div class="field"><label for="c-parent">Parent</label><select id="c-parent" name="parent_id" ${hasKids ? "disabled" : ""}><option value="">None (top level)</option>${parents.map((p) => html`<option value="${p.id}" ${c.parent_id === p.id ? "selected" : ""}>${p.name}</option>`)}</select>
            ${hasKids ? html`<span class="hint">This category has sub-categories, so it stays top level.</span>` : ""}</div>
          <div class="field"><label for="c-sort">Sort order</label><input id="c-sort" name="sort_order" type="number" value="${c.sort_order}"></div></div>
        <div class="field"><label for="c-slug">URL slug</label><input id="c-slug" name="slug" maxlength="120" value="${c.slug}" placeholder="Auto from name"></div>
        <div class="field"><label for="c-desc">Description</label><input id="c-desc" name="description" maxlength="255" value="${c.description || ""}"></div>
        <div class="field"><span class="label">Image (optional)</span><div style="display:flex;gap:12px;align-items:center"><div id="c-prev"></div>
          <button type="button" class="btn btn-ghost btn-sm" id="c-up">${ic("upload", 14)} Upload</button><button type="button" class="btn btn-ghost btn-sm" id="c-rm" hidden>Remove</button><input type="file" id="c-file" accept="image/jpeg,image/png,image/webp,image/gif" hidden></div></div>
        <label class="check"><span class="switch"><input type="checkbox" name="is_active" ${c.is_active ? "checked" : ""}><i></i></span>Visible in the store</label></form>`,
      footer: html`<button class="btn btn-ghost" data-close>Cancel</button><button class="btn btn-primary" id="c-save">${isNew ? "Create" : "Save"}</button>`,
      onMount(box, close) {
        const prev = $("#c-prev", box), rm = $("#c-rm", box);
        const showImg = () => { mount(prev, thumb(image, "Category image")); rm.hidden = !image; };
        showImg();
        $("#c-up", box).addEventListener("click", () => $("#c-file", box).click());
        $("#c-file", box).addEventListener("change", async (e) => { const f = e.target.files[0]; if (!f) return; try { image = await api.upload(f); showImg(); } catch (x) { errToast(x); } e.target.value = ""; });
        rm.addEventListener("click", () => { image = ""; showImg(); });
        const save = $("#c-save", box);
        const submit = async () => {
          const d = formData($("#cf", box));
          if (d.name.trim().length < 2) { toast("Category name is required", "err"); return; }
          const body = { name: d.name.trim(), slug: d.slug.trim(), description: d.description.trim(), image_url: image, sort_order: Number(d.sort_order) || 0, is_active: d.is_active, parent_id: hasKids ? null : d.parent_id || null };
          const r = await busy(save, () => (isNew ? api.post("/categories", body) : api.put("/categories/" + c.id, body)));
          if (r) { toast(isNew ? "Category created" : "Category saved"); close(); load(); }
        };
        save.addEventListener("click", submit);
        $("#cf", box).addEventListener("submit", (e) => { e.preventDefault(); submit(); });
      }
    });
  }
  $("#add").addEventListener("click", () => edit(null));
  load();
}
