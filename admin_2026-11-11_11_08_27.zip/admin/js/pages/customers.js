import { api, qs } from "../api.js";
import { html, mount, $, $$, money, fmtDate, fmtDateTime, ic, pill, pager, debounce, skeletonRows, emptyState, errToast, toast, busy, confirmBox } from "../kit.js";

export default async function (el, params, query, ctx) {
  if (params.id) return detail(el, params, ctx);
  const f = { q: query.q || "", page: Number(query.page) || 1 };
  mount(el, html`<div class="page-head"><div><h1>Customers</h1><p>People with an ORIVO account. Guest buyers appear on their orders only.</p></div></div>
    <div class="filters" role="search"><input class="q" type="search" id="q" placeholder="Search name, email or phone…" aria-label="Search customers" value="${f.q}"></div>
    <div class="card flush"><div id="tbl" aria-live="polite"></div><div id="pg"></div></div>`);
  let reqId = 0;
  async function load() {
    const my = ++reqId; ctx.setQuery({ q: f.q, page: f.page > 1 ? f.page : "" });
    mount($("#tbl"), skeletonRows(8));
    let r; try { r = await api.get("/customers" + qs({ q: f.q, page: f.page, limit: 20 })); } catch (e) { if (my !== reqId || !ctx.alive()) return; errToast(e); mount($("#tbl"), emptyState("Couldn't load customers", e.message)); return; }
    if (my !== reqId || !ctx.alive()) return;
    if (!r.customers.length) { mount($("#tbl"), emptyState("No customers found", f.q ? "Try a different search." : "Accounts created in the store will show up here.")); $("#pg").innerHTML = ""; return; }
    mount($("#tbl"), html`<div class="table-wrap"><table class="cards"><thead><tr><th>Customer</th><th>Phone</th><th class="num">Orders</th><th class="num">Spent</th><th>Joined</th><th>Account</th></tr></thead><tbody>
      ${r.customers.map((c) => html`<tr><td class="main-cell"><a class="link" href="#/customers/${c.id}"><b>${c.name}</b></a><span class="sub">${c.email}</span></td>
        <td data-l="Phone"><a href="tel:${c.phone}">${c.phone}</a></td><td class="num" data-l="Orders">${c.order_count}</td><td class="num" data-l="Spent">${money(c.total_spent)}</td>
        <td data-l="Joined" class="nowrap">${fmtDate(c.created_at)}</td><td data-l="Account">${pill(c.is_active ? "active" : "inactive", c.is_active ? "Active" : "Disabled")}</td></tr>`)}</tbody></table></div>`);
    pager($("#pg"), r, (p) => { f.page = p; load(); scrollTo({ top: 0 }); }, "customers");
  }
  $("#q").addEventListener("input", debounce((e) => { f.q = e.target.value.trim(); f.page = 1; load(); }));
  load();
}

async function detail(el, params, ctx) {
  mount(el, html`<div class="skeleton" style="height:36px;width:240px;margin-bottom:20px"></div><div class="skeleton" style="height:300px"></div>`);
  let r;
  try { r = await api.get("/customers/" + params.id); } catch (e) { if (!ctx.alive()) return; mount(el, html`<div class="empty"><b>${e.status === 404 ? "Customer not found" : "Couldn't load customer"}</b>${e.message}<div class="mt"><a class="btn btn-ghost" href="#/customers">Back to customers</a></div></div>`); return; }
  if (!ctx.alive()) return;
  const c = r.customer, spent = r.orders.filter((o) => o.status !== "cancelled").reduce((s, o) => s + o.total, 0);
  mount(el, html`<a class="crumb" href="#/customers">${ic("left", 14)} All customers</a>
    <div class="page-head"><div><h1>${c.name}</h1><p>Member since ${fmtDate(c.created_at)}</p></div><div class="actions" id="state">${pill(c.is_active ? "active" : "inactive", c.is_active ? "Active" : "Disabled")}
      <button class="btn ${c.is_active ? "btn-danger-ghost" : "btn-primary"}" id="toggle">${c.is_active ? "Disable account" : "Enable account"}</button></div></div>
    <div class="cols"><section class="card flush"><h3 style="padding:20px 20px 0">Orders <small>${r.orders.length} · ${money(spent)} spent</small></h3>
      ${r.orders.length ? html`<div class="table-wrap"><table class="cards"><thead><tr><th>Order</th><th>Status</th><th>Payment</th><th class="num">Total</th><th>Placed</th></tr></thead><tbody>
        ${r.orders.map((o) => html`<tr><td class="main-cell"><a class="link" href="#/orders/${o.id}">${o.orderNumber}</a></td><td data-l="Status">${pill(o.status)}</td><td data-l="Payment">${pill(o.paymentStatus)}</td><td class="num" data-l="Total">${money(o.total)}</td><td data-l="Placed" class="nowrap">${fmtDateTime(o.createdAt)}</td></tr>`)}</tbody></table></div>` : html`<div class="empty"><b>No orders yet</b></div>`}</section>
      <section class="card"><h3>Details</h3><div class="kv"><div><small>Email</small><a class="link" href="mailto:${c.email}">${c.email}</a></div>
        <div><small>Phone</small><a class="link" href="tel:${c.phone}">${c.phone}</a></div>
        <div><small>Saved address</small><span>${c.address || "—"}</span></div>
        <div><small>Preferred zone</small><span>${c.delivery_zone ? c.delivery_zone.replace("_", " ") : "—"}</span></div></div></section></div>`);
  const t = $("#toggle");
  t.addEventListener("click", async () => {
    const disabling = !!c.is_active;
    if (disabling && !(await confirmBox({ title: "Disable this account?", danger: true, confirmText: "Disable", message: `${c.name} won't be able to log in or use member promo codes. Their order history is kept. You can enable the account again any time.` }))) return;
    const ok = await busy(t, () => api.put(`/customers/${c.id}/active`, { is_active: !disabling }));
    if (ok) { toast(disabling ? "Account disabled" : "Account enabled"); detail(el, params, ctx); }
  });
}
