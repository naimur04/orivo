import { api, qs } from "../api.js";
import { html, mount, $, $$, money, fmtDateTime, ic, pill, pager, debounce, skeletonRows, emptyState, errToast, payLabel } from "../kit.js";

export default async function (el, params, query, ctx) {
  const f = { q: query.q || "", status: query.status || "", payment: query.payment || "", preorder: query.preorder === "1", digital: query.digital === "1", guest: query.guest === "1", page: Number(query.page) || 1 };
  mount(el, html`<div class="page-head"><div><h1>Orders</h1><p>Track, confirm and ship customer orders.</p></div></div>
    <div class="filters" role="search">
      <input class="q" type="search" id="q" placeholder="Search order no., name, phone, email…" aria-label="Search orders" value="${f.q}">
      <select id="status" aria-label="Order status"><option value="">All statuses</option>${["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"].map((s) => html`<option value="${s}" ${f.status === s ? "selected" : ""}>${s[0].toUpperCase() + s.slice(1)}</option>`)}</select>
      <select id="payment" aria-label="Payment status"><option value="">Any payment</option>${["pending", "paid", "failed", "refunded"].map((s) => html`<option value="${s}" ${f.payment === s ? "selected" : ""}>Payment: ${s}</option>`)}</select>
      <label class="chip-toggle"><input type="checkbox" id="preorder" ${f.preorder ? "checked" : ""}>Pre-orders</label>
      <label class="chip-toggle"><input type="checkbox" id="digital" ${f.digital ? "checked" : ""}>Digital</label>
      <label class="chip-toggle"><input type="checkbox" id="guest" ${f.guest ? "checked" : ""}>Guest</label>
    </div>
    <div class="card flush"><div id="tbl" aria-live="polite"></div><div id="pg"></div></div>`);

  let reqId = 0;
  async function load() {
    const my = ++reqId;
    ctx.setQuery({ q: f.q, status: f.status, payment: f.payment, preorder: f.preorder, digital: f.digital, guest: f.guest, page: f.page > 1 ? f.page : "" });
    mount($("#tbl"), skeletonRows(8));
    let r;
    try { r = await api.get("/orders" + qs({ q: f.q, status: f.status, payment: f.payment, preorder: f.preorder, digital: f.digital, guest: f.guest, page: f.page, limit: 20 })); }
    catch (e) { if (my !== reqId || !ctx.alive()) return; errToast(e); mount($("#tbl"), emptyState("Couldn't load orders", e.message)); return; }
    if (my !== reqId || !ctx.alive()) return;
    if (!r.orders.length) { mount($("#tbl"), emptyState("No orders found", "Try a different filter or search.")); $("#pg").innerHTML = ""; return; }
    mount($("#tbl"), html`<div class="table-wrap"><table class="cards"><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Status</th><th>Payment</th><th class="num">Total</th><th>Placed</th></tr></thead><tbody>
      ${r.orders.map((o) => html`<tr>
        <td class="main-cell"><a class="link" href="#/orders/${o.id}"><b>${o.orderNumber}</b></a>
          <span class="sub">${o.hasPreorder ? html`<span class="tag pre">Pre-order</span> ` : ""}${o.hasDigital ? html`<span class="tag dig">Digital</span> ` : ""}${o.guest ? html`<span class="tag guest">Guest</span>` : ""}</span></td>
        <td data-l="Customer"><span>${o.customerName}<span class="sub">${o.customerPhone}</span></span></td>
        <td data-l="Items">${o.itemCount ?? ""}</td>
        <td data-l="Status">${pill(o.status)}</td>
        <td data-l="Payment"><span>${pill(o.paymentStatus)}<span class="sub">${payLabel(o.paymentMethod)}</span></span></td>
        <td class="num" data-l="Total"><b>${money(o.total)}</b></td>
        <td data-l="Placed" class="nowrap">${fmtDateTime(o.createdAt)}</td></tr>`)}</tbody></table></div>`);
    pager($("#pg"), r, (p) => { f.page = p; load(); scrollTo({ top: 0 }); }, "orders");
  }
  const reset = () => { f.page = 1; load(); };
  $("#q").addEventListener("input", debounce((e) => { f.q = e.target.value.trim(); reset(); }));
  ["status", "payment"].forEach((k) => $("#" + k).addEventListener("change", (e) => { f[k] = e.target.value; reset(); }));
  ["preorder", "digital", "guest"].forEach((k) => $("#" + k).addEventListener("change", (e) => { f[k] = e.target.checked; reset(); }));
  load();
}
