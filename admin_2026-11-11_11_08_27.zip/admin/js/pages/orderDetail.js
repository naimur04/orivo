import { api } from "../api.js";
import { html, raw, esc, mount, $, $$, money, fmtDateTime, fmtDate, ic, pill, thumb, confirmBox, errToast, toast, busy, payLabel } from "../kit.js";

const FLOW = ["pending", "confirmed", "processing", "shipped", "delivered"];
const NEXT_LABEL = { confirmed: "Confirm order", processing: "Start processing", shipped: "Mark as shipped", delivered: "Mark as delivered" };
const NAME = { pending: "Placed", confirmed: "Confirmed", processing: "Processing", shipped: "Shipped", delivered: "Delivered", cancelled: "Cancelled" };
const histLabel = (h) => (h.status.startsWith("payment:") ? "Payment " + h.status.slice(8) : h.label || NAME[h.status] || h.status);

export default async function (el, params, query, ctx) {
  mount(el, html`<div class="skeleton" style="height:36px;width:260px;margin-bottom:20px"></div><div class="skeleton" style="height:380px"></div>`);
  async function load() {
    let o;
    try { o = (await api.get("/orders/" + params.id)).order; }
    catch (e) { if (!ctx.alive()) return; mount(el, html`<div class="empty"><b>${e.status === 404 ? "Order not found" : "Couldn't load this order"}</b>${e.message}<div class="mt"><a class="btn btn-ghost" href="#/orders">Back to orders</a></div></div>`); return; }
    if (!ctx.alive()) return;
    draw(o);
  }

  function draw(o) {
    const cancelled = o.status === "cancelled";
    const idx = FLOW.indexOf(o.status);
    const next = !cancelled && idx >= 0 && idx < FLOW.length - 1 ? FLOW[idx + 1] : null;
    const maps = o.address && o.hasPhysical !== false ? "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(o.address) : "";
    const subtotal = o.subtotal, hasDigitalOnly = o.items.every((i) => i.type === "digital");
    mount(el, html`
      <a class="crumb no-print" href="#/orders">${ic("left", 14)} All orders</a>
      <div class="page-head no-print"><div><h1>${o.orderNumber}</h1>
        <p>Placed ${fmtDateTime(o.createdAt)} · ${o.guest ? html`<span class="tag guest">Guest checkout</span>` : html`<a class="link" href="#/customers/${o.customerId}">Registered customer</a>`}</p></div>
        <div class="actions">${pill(o.status)} ${pill(o.paymentStatus, "Payment: " + o.paymentStatus)}
          <button class="btn btn-ghost" id="print">${ic("print")} Print invoice</button></div></div>

      <div class="cols no-print">
        <div class="stack">
          <section class="card" aria-label="Order progress"><h3>Progress</h3>
            <ol class="steps" style="list-style:none;padding:0">${cancelled
              ? html`<li class="step bad now" style="flex:1">Order cancelled</li>`
              : FLOW.map((s, i) => html`<li class="step ${i < idx ? "done" : i === idx ? "now done" : ""}" ${i === idx ? 'aria-current="step"' : ""}>${NAME[s]}</li>`)}</ol>
            ${cancelled ? html`<div class="notice err">${ic("warn")}<span>This order was cancelled. Stock and any promo use were returned. A cancelled order can't be re-opened.</span></div>`
              : o.status === "delivered" ? html`<div class="notice ice">${ic("check")}<span>Delivered. Nothing more to do on this order.</span></div>`
              : html`<div class="field"><label for="snote">Note for the timeline (optional)</label><input id="snote" maxlength="255" placeholder="e.g. Courier: Pathao, tracking 12345"></div>
                <div class="actions">${next ? html`<button class="btn btn-primary" id="adv" data-s="${next}">${NEXT_LABEL[next]} ${ic("right", 15)}</button>` : ""}
                <button class="btn btn-danger-ghost" id="cancel">Cancel order</button></div>`}
          </section>

          <section class="card" aria-label="Items"><h3>Items <small>${o.items.length} line${o.items.length === 1 ? "" : "s"}</small></h3>
            <div class="items">${o.items.map((i) => html`<div class="it">${thumb(i.image, i.name)}
              <div><b>${i.name}</b><div class="faint" style="font-size:12px">${[i.sku, i.size && "Size " + i.size, i.color].filter(Boolean).join(" · ")}</div>
                <div style="margin-top:4px">${i.availability === "preorder" ? html`<span class="tag pre">Pre-order</span> ` : ""}${i.type === "digital" ? html`<span class="tag dig">Digital</span>` : ""}</div></div>
              <div class="right nowrap"><div>${money(i.price)} × ${i.quantity}</div><b>${money(i.total)}</b></div></div>`)}</div>
            <div class="sums"><div><span>Subtotal</span><span>${money(subtotal)}</span></div>
              ${o.discount ? html`<div class="disc"><span>Promo ${o.promoCode ? html`<span class="tag">${o.promoCode}</span>` : ""}</span><span>−${money(o.discount)}</span></div>` : ""}
              <div><span>Delivery ${o.deliveryZone && o.deliveryZone !== "digital" ? html`<span class="faint">(${o.deliveryZone.replace("_", " ")})</span>` : ""}</span><span>${o.delivery ? money(o.delivery) : "Free"}</span></div>
              <div class="total"><span>Total</span><span>${money(o.total)}</span></div></div>
          </section>

          <section class="card" aria-label="Timeline"><h3>Timeline</h3>
            <ul class="timeline">${[...o.history].reverse().map((h) => html`<li class="${h.status.startsWith("payment:") ? "pay" : ""}"><b>${histLabel(h)}</b>
              <small>${fmtDateTime(h.created_at)} · ${h.changed_by || "system"}</small>${h.note && h.note !== histLabel(h) && h.note !== h.label ? html`<div class="muted">${h.note}</div>` : ""}</li>`)}</ul>
          </section>
        </div>

        <div class="stack">
          <section class="card"><h3>Customer</h3><div class="kv">
            <div><small>Name</small><b>${o.customerName}</b></div>
            <div><small>Phone</small><a class="link" href="tel:${o.customerPhone}">${ic("phone", 14)} ${o.customerPhone}</a></div>
            ${o.customerEmail ? html`<div><small>Email</small><a class="link" href="mailto:${o.customerEmail}">${o.customerEmail}</a></div>` : ""}
            <div><small>${hasDigitalOnly ? "Delivery" : "Shipping address"}</small><span>${o.address}</span>${maps && !hasDigitalOnly ? html`<a class="link" href="${maps}" target="_blank" rel="noopener" style="font-size:12px">Open in Maps</a>` : ""}</div>
            ${o.notes ? html`<div><small>Customer note</small><span>${o.notes}</span></div>` : ""}</div></section>

          <section class="card"><h3>Payment</h3><div class="kv"><div><small>Method</small><b>${payLabel(o.paymentMethod)}</b></div></div>
            <div class="field mt-s"><label for="pay">Payment status</label>
              <select id="pay">${["pending", "paid", "failed", "refunded"].map((s) => html`<option value="${s}" ${o.paymentStatus === s ? "selected" : ""}>${s[0].toUpperCase() + s.slice(1)}</option>`)}</select>
              <span class="hint">${o.paymentMethod === "cod" ? "Cash on delivery is marked paid automatically when you deliver the order." : "Online payments are updated by the gateway."}</span></div>
            <button class="btn btn-ghost btn-sm" id="paysave" disabled>Save payment status</button>
            ${o.transactions.length ? html`<div class="list mt">${o.transactions.map((t) => html`<div class="li"><span><b>${t.provider}</b><span class="faint" style="display:block;font-size:12px">${t.provider_trx_id || "—"} · ${fmtDateTime(t.created_at)}</span></span><span class="right">${money(t.amount)}<br>${pill(t.status === "success" ? "paid" : "failed", t.status)}</span></div>`)}</div>` : ""}
          </section>

          <section class="card"><h3>Internal note</h3>
            <div class="field"><label class="sr" for="anote">Admin note</label><textarea id="anote" maxlength="1000" placeholder="Only visible to staff">${o.adminNote}</textarea></div>
            <button class="btn btn-ghost btn-sm" id="notesave">Save note</button></section>
        </div>
      </div>

      <div class="invoice" aria-hidden="true">
        <h1>ORIVO</h1><p>Invoice / packing slip · ${esc(o.orderNumber)} · ${esc(fmtDate(o.createdAt))}</p><hr>
        <p><b>${esc(o.customerName)}</b><br>${esc(o.customerPhone)}${o.customerEmail ? "<br>" + esc(o.customerEmail) : ""}<br>${esc(o.address)}</p>
        <table style="margin-top:12px"><thead><tr><th>Item</th><th>Options</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>
          ${raw(o.items.map((i) => `<tr><td>${esc(i.name)}${i.availability === "preorder" ? " (pre-order)" : ""}</td><td>${esc([i.size, i.color].filter(Boolean).join(" / "))}</td><td>${i.quantity}</td><td>${esc(money(i.price))}</td><td>${esc(money(i.total))}</td></tr>`).join(""))}
        </tbody></table>
        <div class="tot"><div><span>Subtotal</span><span>${money(o.subtotal)}</span></div>${o.discount ? html`<div><span>Discount</span><span>−${money(o.discount)}</span></div>` : ""}
          <div><span>Delivery</span><span>${money(o.delivery)}</span></div><div class="g"><span>${o.paymentMethod === "cod" && o.paymentStatus !== "paid" ? "Collect on delivery" : "Total"}</span><span>${money(o.total)}</span></div></div>
        <p style="margin-top:18px">Payment: ${esc(payLabel(o.paymentMethod))} (${esc(o.paymentStatus)}). Thank you for shopping with ORIVO.</p>
      </div>`);

    $("#print").addEventListener("click", () => window.print());
    const adv = $("#adv");
    async function change(status, btn, extra = {}) {
      const r = await busy(btn, () => api.put(`/orders/${o.id}/status`, { status, note: $("#snote")?.value.trim() || undefined, ...extra }));
      if (r) { toast("Order updated"); ctx.refreshBadge(); load(); }
    }
    adv?.addEventListener("click", () => change(adv.dataset.s, adv));
    $("#cancel")?.addEventListener("click", async (e) => {
      const ok = await confirmBox({ title: "Cancel this order?", danger: true, confirmText: "Cancel order",
        message: "Stock for in-stock items goes back on the shelf and any promo code use is returned. A cancelled order can't be re-opened." });
      if (ok) change("cancelled", e.currentTarget);
    });
    const pay = $("#pay"), paysave = $("#paysave");
    pay.addEventListener("change", () => { paysave.disabled = pay.value === o.paymentStatus; });
    paysave.addEventListener("click", async () => { const r = await busy(paysave, () => api.put(`/orders/${o.id}/payment`, { payment_status: pay.value })); if (r) { toast("Payment status saved"); load(); } });
    const ns = $("#notesave");
    ns.addEventListener("click", async () => { const r = await busy(ns, () => api.put(`/orders/${o.id}/note`, { note: $("#anote").value })); if (r) toast("Note saved"); });
  }
  load();
}
