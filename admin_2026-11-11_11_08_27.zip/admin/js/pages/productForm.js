import { api } from "../api.js";
import { html, raw, esc, mount, $, $$, ic, toast, errToast, busy, dateOnly, confirmBox } from "../kit.js";

const MAX_IMAGES = 10;
const list = (s) => String(s || "").split(",").map((x) => x.trim()).filter(Boolean);

/** Tag-style input: Enter / comma adds, Backspace removes the last chip. */
function chipsInput(root, initial, placeholder) {
  let tags = [...initial];
  const box = document.createElement("div"); box.className = "chips";
  const input = document.createElement("input"); input.placeholder = placeholder; input.setAttribute("aria-label", placeholder);
  const draw = () => {
    box.querySelectorAll(".c").forEach((c) => c.remove());
    tags.forEach((t, i) => { const c = document.createElement("span"); c.className = "c"; c.append(t);
      const b = document.createElement("button"); b.type = "button"; b.setAttribute("aria-label", "Remove " + t); b.innerHTML = ic("x", 12).__raw;
      b.addEventListener("click", () => { tags.splice(i, 1); draw(); input.focus(); }); c.append(b); box.insertBefore(c, input); });
  };
  const add = (v) => { v = v.trim(); if (v && !tags.some((t) => t.toLowerCase() === v.toLowerCase()) && tags.length < 30) tags.push(v); input.value = ""; draw(); };
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === ",") { e.preventDefault(); add(input.value); }
    else if (e.key === "Backspace" && !input.value && tags.length) { tags.pop(); draw(); }
  });
  input.addEventListener("blur", () => add(input.value));
  input.addEventListener("input", () => { if (input.value.includes(",")) input.value.split(",").forEach((p) => add(p)); });
  box.addEventListener("click", () => input.focus());
  box.append(input); root.append(box); draw();
  return { value: () => { add(input.value); return tags.join(","); } };
}

export default async function (el, params, query, ctx) {
  const editing = !!params.id;
  let cats = [], p = null;
  try {
    const [c, pr] = await Promise.all([api.get("/categories"), editing ? api.get("/products/" + params.id) : null]);
    cats = c.categories; p = pr ? pr.product : null;
  } catch (e) { if (!ctx.alive()) return; mount(el, html`<div class="empty"><b>${e.status === 404 ? "Product not found" : "Couldn't load"}</b>${e.message}<div class="mt"><a class="btn btn-ghost" href="#/products">Back to products</a></div></div>`); return; }
  if (!ctx.alive()) return;

  const v = p || { name: "", slug: "", sku: "", short_description: "", description: "", category_id: "", product_type: "physical", availability: "available", preorder_date: "", preorder_note: "",
    billing_period: "one_time", regular_price: "", sale_price: "", stock_quantity: 0, track_stock: 1, sizes: "", colors: "", badge: "", status: "draft", featured: 0, images: [] };
  let images = [...(v.images || [])];
  const active = cats.filter((c) => c.is_active || c.id === v.category_id);
  const parents = active.filter((c) => !c.parent_id);

  mount(el, html`
    <a class="crumb" href="#/products">${ic("left", 14)} All products</a>
    <div class="page-head"><div><h1>${editing ? "Edit product" : "New product"}</h1><p>${editing ? v.name : "Fill in the details, add photos, then publish when ready."}</p></div>
      ${editing && v.status === "active" ? html`<a class="btn btn-ghost" href="/#/product/${v.slug}" target="_blank" rel="noopener">${ic("ext")} View in store</a>` : ""}</div>
    <form id="pf" novalidate>
      <div class="form-grid">
        <div class="stack">
          <section class="card"><h3>Basics</h3>
            <div class="field"><label for="name">Product name *</label><input id="name" name="name" required maxlength="180" value="${v.name}"></div>
            <div class="grid2"><div class="field"><label for="sku">SKU</label><input id="sku" name="sku" maxlength="100" value="${v.sku || ""}" placeholder="Auto / optional"></div>
              <div class="field"><label for="slug">URL slug</label><input id="slug" name="slug" maxlength="120" value="${v.slug || ""}" placeholder="Auto from name"><span class="hint">Leave empty to generate from the name.</span></div></div>
            <div class="field"><label for="short_description">Short description</label><input id="short_description" name="short_description" maxlength="255" value="${v.short_description || ""}"><span class="hint">Shown on cards and in search results.</span></div>
            <div class="field"><label for="description">Full description</label><textarea id="description" name="description" rows="7" maxlength="10000">${v.description || ""}</textarea></div>
          </section>

          <section class="card"><h3>Photos <small><span id="imgcount"></span> / ${MAX_IMAGES} · first photo is the cover</small></h3>
            <div class="drop" id="drop" tabindex="0" role="button" aria-label="Add product photos">${ic("upload", 28)}<div><b>Click to upload</b> or drag photos here</div><small>JPG, PNG, WEBP or GIF · up to 8 MB each</small></div>
            <input type="file" id="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple hidden>
            <div class="imgs" id="imgs" aria-live="polite"></div>
          </section>

          <section class="card"><h3>Variants</h3><p class="muted" style="margin-bottom:12px;font-size:13px">Customers must choose a size / colour when you add some. Press Enter or comma after each one. Physical products only.</p>
            <div class="grid2"><div class="field"><label>Sizes</label><div id="sizes"></div></div><div class="field"><label>Colours</label><div id="colors"></div></div></div>
          </section>
        </div>

        <div class="stack">
          <section class="card"><h3>Publish</h3>
            <div class="field"><label for="status">Status</label><select id="status" name="status">${[["active", "Active (visible in store)"], ["inactive", "Inactive (hidden)"], ["draft", "Draft"]].map(([k, l]) => html`<option value="${k}" ${v.status === k ? "selected" : ""}>${l}</option>`)}</select></div>
            <label class="check" style="margin-bottom:6px"><span class="switch"><input type="checkbox" name="featured" ${v.featured ? "checked" : ""}><i></i></span>Featured on the home page</label>
            <div class="field mt-s"><label for="badge">Badge</label><input id="badge" name="badge" maxlength="40" value="${v.badge || ""}" placeholder="e.g. New, Bestseller"></div>
          </section>

          <section class="card"><h3>Section &amp; type</h3>
            <div class="field"><span class="label" id="l-av">Store section</span><div class="seg" role="radiogroup" aria-labelledby="l-av">
              <label><input type="radio" name="availability" value="available" ${v.availability !== "preorder" ? "checked" : ""}>Available</label>
              <label class="pre"><input type="radio" name="availability" value="preorder" ${v.availability === "preorder" ? "checked" : ""}>Pre-order</label></div></div>
            <div class="field"><span class="label" id="l-ty">Product type</span><div class="seg" role="radiogroup" aria-labelledby="l-ty">
              <label><input type="radio" name="product_type" value="physical" ${v.product_type !== "digital" ? "checked" : ""}>Physical</label>
              <label><input type="radio" name="product_type" value="digital" ${v.product_type === "digital" ? "checked" : ""}>Digital</label></div></div>
            <div id="pre-box"><div class="field"><label for="preorder_date">Expected arrival</label><input id="preorder_date" name="preorder_date" type="date" value="${dateOnly(v.preorder_date)}"></div>
              <div class="field"><label for="preorder_note">Pre-order note</label><input id="preorder_note" name="preorder_note" maxlength="255" value="${v.preorder_note || ""}" placeholder="Ships when it arrives. Pay on delivery."></div></div>
            <div id="dig-box" class="field"><label for="billing_period">Billing</label><select id="billing_period" name="billing_period">${[["one_time", "One-time purchase"], ["monthly", "Monthly subscription"], ["yearly", "Yearly subscription"]].map(([k, l]) => html`<option value="${k}" ${v.billing_period === k ? "selected" : ""}>${l}</option>`)}</select>
              <span class="hint">Digital items are delivered by email, so customers must give an email at checkout.</span></div>
          </section>

          <section class="card"><h3>Organise</h3>
            <div class="field"><label for="category_id">Category</label><select id="category_id" name="category_id"><option value="">No category</option>
              ${parents.map((c) => html`<optgroup label="${c.name}"><option value="${c.id}" ${v.category_id === c.id ? "selected" : ""}>${c.name} (general)</option>${active.filter((x) => x.parent_id === c.id).map((x) => html`<option value="${x.id}" ${v.category_id === x.id ? "selected" : ""}>${x.name}</option>`)}</optgroup>`)}</select></div>
          </section>

          <section class="card"><h3>Pricing &amp; stock</h3>
            <div class="grid2"><div class="field"><label for="regular_price">Regular price (৳) *</label><input id="regular_price" name="regular_price" type="number" min="0" step="0.01" inputmode="decimal" required value="${v.regular_price}"></div>
              <div class="field"><label for="sale_price">Sale price (৳)</label><input id="sale_price" name="sale_price" type="number" min="0" step="0.01" inputmode="decimal" value="${v.sale_price ?? ""}"></div></div>
            <div class="err-text" id="price-err" role="alert" hidden></div>
            <div id="stock-box"><div class="field mt-s"><label for="stock_quantity">Stock quantity</label><input id="stock_quantity" name="stock_quantity" type="number" min="0" step="1" value="${v.stock_quantity ?? 0}"></div>
              <label class="check"><span class="switch"><input type="checkbox" name="track_stock" ${v.track_stock || !editing ? "checked" : ""}><i></i></span>Track stock (block sales at 0)</label></div>
            <p class="faint" id="stock-off" style="font-size:12px" hidden>Pre-order and digital items aren't limited by stock.</p>
          </section>
        </div>
      </div>
      <div class="sticky-save"><a class="btn btn-ghost" href="#/products">Cancel</a><button class="btn btn-primary" type="submit" id="save">${editing ? "Save changes" : "Create product"}</button></div>
    </form>`);

  const form = $("#pf");
  const sizes = chipsInput($("#sizes"), list(v.sizes), "Add a size…");
  const colors = chipsInput($("#colors"), list(v.colors), "Add a colour…");

  /* conditional sections */
  const val = (n) => form.elements[n].value;
  function sync() {
    const pre = val("availability") === "preorder", dig = val("product_type") === "digital";
    $("#pre-box").hidden = !pre; $("#dig-box").hidden = !dig;
    $("#stock-box").hidden = dig || pre; $("#stock-off").hidden = !(dig || pre);
    $("#sizes").closest(".card").hidden = dig;
  }
  $$("input[name=availability],input[name=product_type]", form).forEach((r) => r.addEventListener("change", sync)); sync();

  /* price validation */
  const priceCheck = () => {
    const r = parseFloat(val("regular_price")), s = val("sale_price") === "" ? null : parseFloat(val("sale_price"));
    const bad = s !== null && (isNaN(s) || s <= 0 || (!isNaN(r) && s >= r));
    const e = $("#price-err"); e.hidden = !bad; e.textContent = bad ? "Sale price must be greater than 0 and lower than the regular price." : "";
    form.elements.sale_price.setAttribute("aria-invalid", bad); return !bad;
  };
  ["regular_price", "sale_price"].forEach((n) => form.elements[n].addEventListener("input", priceCheck));

  /* images */
  const imgsEl = $("#imgs");
  const drawImgs = (uploading = 0) => {
    $("#imgcount").textContent = images.length;
    imgsEl.innerHTML = images.map((u, i) => `<div class="img ${i === 0 ? "first" : ""}" data-i="${i}"><img src="${esc(u)}" alt="Photo ${i + 1}">${i === 0 ? '<span class="primary">Cover</span>' : ""}
      <div class="tools"><button type="button" data-a="l" aria-label="Move photo ${i + 1} earlier" ${i === 0 ? "disabled" : ""}>${ic("left", 14).__raw}</button>
      <button type="button" data-a="r" aria-label="Move photo ${i + 1} later" ${i === images.length - 1 ? "disabled" : ""}>${ic("right", 14).__raw}</button>
      <button type="button" data-a="x" aria-label="Remove photo ${i + 1}">${ic("trash", 14).__raw}</button></div></div>`).join("")
      + Array.from({ length: uploading }, () => '<div class="img up skeleton">Uploading…</div>').join("");
  };
  imgsEl.addEventListener("click", (e) => {
    const b = e.target.closest("button[data-a]"); if (!b) return;
    const i = Number(b.closest(".img").dataset.i), a = b.dataset.a;
    if (a === "x") images.splice(i, 1);
    else { const j = a === "l" ? i - 1 : i + 1; [images[i], images[j]] = [images[j], images[i]]; }
    drawImgs();
  });
  let uploading = 0;
  async function addFiles(files) {
    files = [...files];
    const room = MAX_IMAGES - images.length - uploading;
    if (files.length > room) { toast(`You can add ${Math.max(room, 0)} more photo${room === 1 ? "" : "s"} (max ${MAX_IMAGES})`, "err"); files = files.slice(0, Math.max(room, 0)); }
    uploading += files.length; drawImgs(uploading);
    for (const f of files) {
      try { images.push(await api.upload(f)); } catch (e) { errToast(e); }
      uploading--; drawImgs(uploading);
    }
  }
  const drop = $("#drop"), file = $("#file");
  drop.addEventListener("click", () => file.click());
  drop.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); file.click(); } });
  file.addEventListener("change", () => { addFiles(file.files); file.value = ""; });
  ["dragenter", "dragover"].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", (e) => addFiles(e.dataTransfer.files));
  drawImgs();

  /* save */
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#save");
    if (val("name").trim().length < 2) { toast("Please enter a product name", "err"); form.elements.name.focus(); return; }
    if (!(parseFloat(val("regular_price")) > 0)) { toast("Regular price must be greater than 0", "err"); form.elements.regular_price.focus(); return; }
    if (!priceCheck()) { form.elements.sale_price.focus(); return; }
    if (uploading) { toast("Please wait for photos to finish uploading", "err"); return; }
    const pre = val("availability") === "preorder", dig = val("product_type") === "digital";
    const body = {
      name: val("name").trim(), slug: val("slug").trim(), sku: val("sku").trim(), short_description: val("short_description").trim(), description: val("description").trim(),
      category_id: val("category_id") || null, product_type: val("product_type"), availability: val("availability"),
      preorder_date: pre ? val("preorder_date") : "", preorder_note: pre ? val("preorder_note") : "", billing_period: dig ? val("billing_period") : "one_time",
      regular_price: val("regular_price"), sale_price: val("sale_price") === "" ? null : val("sale_price"),
      stock_quantity: val("stock_quantity") || 0, track_stock: !!form.elements.track_stock.checked,
      sizes: dig ? "" : sizes.value(), colors: dig ? "" : colors.value(), badge: val("badge").trim(), status: val("status"), featured: form.elements.featured.checked, images
    };
    const r = await busy(btn, () => (editing ? api.put("/products/" + params.id, body) : api.post("/products", body)));
    if (r) { toast(editing ? "Product saved" : "Product created"); ctx.go("#/products"); }
  });
}
