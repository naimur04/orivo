import { api } from "../api.js";
import { html, mount, $, ic, toast, busy, errToast, formData } from "../kit.js";

const NUM = ["delivery_inside_dhaka", "delivery_outside_dhaka", "free_delivery_threshold", "low_stock_threshold"];

export default async function (el, params, query, ctx) {
  let r;
  try { r = await api.get("/settings"); } catch (e) { if (!ctx.alive()) return; mount(el, html`<div class="empty"><b>Couldn't load settings</b>${e.message}</div>`); return; }
  if (!ctx.alive()) return;
  const s = r.settings, can = ["owner", "manager"].includes(ctx.admin.role), dis = can ? "" : "disabled";
  const F = (name, label, type = "text", extra = "") => html`<div class="field"><label for="s-${name}">${label}</label><input id="s-${name}" name="${name}" type="${type}" value="${s[name] ?? ""}" ${type === "number" ? 'min="0" step="1" inputmode="numeric"' : ""} ${dis}>${extra ? html`<span class="hint">${extra}</span>` : ""}</div>`;
  mount(el, html`<div class="page-head"><div><h1>Settings</h1><p>Store details, delivery fees and payment methods.</p></div></div>
    ${can ? "" : html`<div class="notice amber" style="margin-bottom:16px">${ic("info")}<span>Only owners and managers can change settings. You can view them here.</span></div>`}
    <form id="sf" novalidate><div class="cols">
      <div class="stack">
        <section class="card"><h3>Store</h3>${F("store_name", "Store name")}${F("tagline", "Tagline")}${F("announcement", "Announcement bar", "text", "Shown at the very top of the store. Leave empty to hide.")}</section>
        <section class="card"><h3>Contact</h3><div class="grid2">${F("contact_phone", "Phone")}${F("contact_email", "Email", "email")}</div>${F("contact_address", "Address")}</section>
        <section class="card"><h3>Delivery</h3><div class="grid2">${F("delivery_inside_dhaka", "Inside Dhaka (৳)", "number")}${F("delivery_outside_dhaka", "Outside Dhaka (৳)", "number")}</div>
          ${F("free_delivery_threshold", "Free delivery over (৳)", "number", "Set 0 to disable free delivery.")}${F("low_stock_threshold", "Low-stock warning at", "number", "Products at or below this many units appear in Low stock.")}</section>
        ${can ? html`<div class="actions"><button class="btn btn-primary" type="submit" id="save">Save settings</button></div>` : ""}
      </div>
      <div class="stack"><section class="card"><h3>Payment methods</h3>
        <div class="list">${r.paymentMethods.map((m) => html`<div class="li"><span><b>${m.label}</b><span class="faint" style="display:block;font-size:12px">${m.online ? "Online payment" : "Pay at the door"}</span></span>
          ${m.enabled ? html`<span class="pill st-active">Enabled</span>` : html`<span class="pill st-draft">Not enabled</span>`}</div>`)}</div>
        <div class="notice mt">${ic("info")}<span>Cash on Delivery is always on. bKash, Nagad, Rocket and card payments are switched on in <code>server/.env</code> (e.g. <code>BKASH_ENABLED=true</code>) once their provider file in <code>server/services/payments/</code> is implemented. They then appear at checkout automatically.</span></div></section></div>
    </div></form>`);
  const f = $("#sf"), save = $("#save");
  f.addEventListener("submit", async (e) => {
    e.preventDefault(); if (!can) return;
    const d = formData(f);
    for (const k of NUM) if (d[k] === "" || Number(d[k]) < 0 || !Number.isFinite(Number(d[k]))) { toast("Delivery and stock values must be 0 or more", "err"); return; }
    if (!d.store_name.trim()) { toast("Store name can't be empty", "err"); return; }
    const out = await busy(save, () => api.put("/settings", d));
    if (out) toast("Settings saved");
  });
}
