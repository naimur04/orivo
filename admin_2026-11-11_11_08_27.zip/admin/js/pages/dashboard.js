import { api } from "../api.js";
import { html, raw, esc, mount, $, $$, money, fmtDate, ic, pill, thumb, errToast } from "../kit.js";

const STATUS_ORDER = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"];
const STATUS_NAME = { pending: "Pending", confirmed: "Confirmed", processing: "Processing", shipped: "Shipped", delivered: "Delivered", cancelled: "Cancelled" };

function chart(series) {
  const W = 760, H = 270, L = 52, R = 44, T = 16, B = 34, iw = W - L - R, ih = H - T - B;
  const maxRev = Math.max(...series.map((s) => s.revenue), 1), maxOrd = Math.max(...series.map((s) => s.orders), 1);
  const nice = (v) => { const p = Math.pow(10, Math.floor(Math.log10(v))); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p; };
  const yMax = nice(maxRev), oMax = Math.max(nice(maxOrd), 4);
  const step = iw / series.length, bw = Math.min(step * 0.58, 30);
  const x = (i) => L + step * i + step / 2;
  const yR = (v) => T + ih - (v / yMax) * ih, yO = (v) => T + ih - (v / oMax) * ih;
  const short = (v) => (v >= 1000 ? (v / 1000).toFixed(v % 1000 ? 1 : 0) + "k" : String(v));
  let g = "";
  for (let k = 0; k <= 4; k++) {
    const y = T + (ih / 4) * k;
    g += `<line class="gridline" x1="${L}" x2="${W - R}" y1="${y}" y2="${y}"/><text x="${L - 8}" y="${y + 4}" text-anchor="end">৳${short(Math.round(yMax - (yMax / 4) * k))}</text><text x="${W - R + 8}" y="${y + 4}">${Math.round(oMax - (oMax / 4) * k)}</text>`;
  }
  let bars = "", labels = "";
  series.forEach((s, i) => {
    const h = Math.max((s.revenue / yMax) * ih, s.revenue ? 2 : 0);
    const label = `${fmtDate(s.date, { day: "numeric", month: "short" })}: ${s.orders} orders, ${money(s.revenue)}`;
    bars += `<g data-i="${i}"><rect class="hit" x="${L + step * i}" y="${T}" width="${step}" height="${ih}" tabindex="0" role="img" aria-label="${esc(label)}"/>
      <rect class="bar" x="${x(i) - bw / 2}" y="${T + ih - h}" width="${bw}" height="${h}" rx="5" opacity=".78" pointer-events="none"/></g>`;
    if (i % 2 === 0 || series.length < 9) labels += `<text x="${x(i)}" y="${H - 10}" text-anchor="middle">${fmtDate(s.date, { day: "numeric", month: "short" })}</text>`;
  });
  const pts = series.map((s, i) => `${x(i).toFixed(1)},${yO(s.orders).toFixed(1)}`);
  const dots = series.map((s, i) => (s.orders ? `<circle class="dot" cx="${x(i).toFixed(1)}" cy="${yO(s.orders).toFixed(1)}" r="3.5" pointer-events="none"/>` : "")).join("");
  return raw(`<div class="chart"><div class="tip" id="tip" role="status"></div>
    <svg viewBox="0 0 ${W} ${H}" role="group" aria-label="Revenue and orders for the last 14 days">
      <defs><linearGradient id="revg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8fd3ff"/><stop offset="1" stop-color="#2f6fb5"/></linearGradient></defs>
      ${g}${bars}<polyline class="line" points="${pts.join(" ")}" pointer-events="none"/>${dots}${labels}</svg></div>`);
}

function bindChart(el, series) {
  const tip = $("#tip", el), wrap = $(".chart", el); if (!wrap) return;
  const show = (g) => {
    const s = series[Number(g.dataset.i)], hit = $(".hit", g).getBoundingClientRect(), box = wrap.getBoundingClientRect();
    tip.innerHTML = `<b>${esc(fmtDate(s.date, { weekday: "short", day: "numeric", month: "short" }))}</b>${esc(money(s.revenue))} · ${s.orders} order${s.orders === 1 ? "" : "s"}`;
    tip.style.left = hit.left + hit.width / 2 - box.left + "px"; tip.style.top = Math.max(hit.top - box.top + 60, 30) + "px";
    tip.classList.add("show"); $$("g[data-i]", el).forEach((x) => x.classList.toggle("on", x === g));
  };
  const hide = () => { tip.classList.remove("show"); $$("g[data-i]", el).forEach((x) => x.classList.remove("on")); };
  $$("g[data-i]", el).forEach((g) => {
    g.addEventListener("mouseenter", () => show(g)); g.addEventListener("mouseleave", hide);
    $(".hit", g).addEventListener("focus", () => show(g)); $(".hit", g).addEventListener("blur", hide);
  });
}

export default async function (el, params, query, ctx) {
  mount(el, html`<div class="page-head"><div><h1>Dashboard</h1><p>Welcome back, ${ctx.admin.name}. Here's how ORIVO is doing.</p></div>
    <div class="actions"><a class="btn btn-ghost" href="#/products/new">${ic("plus")} Add product</a><a class="btn btn-primary" href="#/orders">${ic("orders")} View orders</a></div></div>
    <div class="kpis">${Array.from({ length: 8 }, () => html`<div class="skeleton" style="height:96px"></div>`)}</div>`);
  let d;
  try { d = await api.get("/dashboard"); } catch (e) { if (!ctx.alive()) return; errToast(e); mount(el, html`<div class="empty"><b>Couldn't load the dashboard</b>${e.message}</div>`); return; }
  if (!ctx.alive()) return;
  const t = d.totals, total14 = d.series.reduce((s, x) => s + x.revenue, 0), ord14 = d.series.reduce((s, x) => s + x.orders, 0);
  const maxStatus = Math.max(...d.byStatus.map((s) => s.n), 1);
  const byStatus = STATUS_ORDER.map((s) => ({ status: s, n: (d.byStatus.find((x) => x.status === s) || {}).n || 0 }));
  mount(el, html`
    <div class="page-head"><div><h1>Dashboard</h1><p>Welcome back, ${ctx.admin.name}. Here's how ORIVO is doing.</p></div>
      <div class="actions"><a class="btn btn-ghost" href="#/products/new">${ic("plus")} Add product</a><a class="btn btn-primary" href="#/orders">${ic("orders")} View orders</a></div></div>
    <div class="kpis">
      <div class="card kpi ice"><small>Today's revenue</small><b>${money(t.todayRevenue)}</b><em>${t.todayOrders} order${t.todayOrders === 1 ? "" : "s"} today</em></div>
      <div class="card kpi"><small>Total revenue</small><b>${money(t.revenue)}</b><em>${t.orders} orders (excl. cancelled)</em></div>
      <div class="card kpi ${t.pending ? "hot" : ""}"><small>Pending orders</small><b>${t.pending}</b><em>Waiting to be confirmed</em><a href="#/orders?status=pending" aria-label="Show pending orders"></a></div>
      <div class="card kpi ${t.preorderOpen ? "hot" : ""}"><small>Open pre-orders</small><b>${t.preorderOpen}</b><em>Not yet delivered</em><a href="#/orders?preorder=1" aria-label="Show pre-orders"></a></div>
      <div class="card kpi"><small>Today's orders</small><b>${t.todayOrders}</b><em>Since midnight</em></div>
      <div class="card kpi"><small>Last 14 days</small><b>${money(total14)}</b><em>${ord14} orders</em></div>
      <div class="card kpi"><small>Customers</small><b>${t.customers}</b><em>Registered accounts</em>${ctx.admin.role !== "staff" ? html`<a href="#/customers" aria-label="Open customers"></a>` : ""}</div>
      <div class="card kpi"><small>Active products</small><b>${t.products}</b><em>Visible in the store</em><a href="#/products?status=active" aria-label="Open products"></a></div>
    </div>
    <div class="dash">
      <section class="card" aria-label="Sales chart"><h3>Sales, last 14 days <small>Bars: revenue · Line: orders</small></h3>
        <div class="legend"><span><i></i>Revenue (৳)</span><span><i class="o"></i>Orders</span></div>${chart(d.series)}</section>
      <section class="card"><h3>Orders by status</h3>
        <div class="bars">${byStatus.map((s) => html`<a class="r st-${s.status}" href="#/orders?status=${s.status}"><span>${STATUS_NAME[s.status]}</span><span class="track"><i style="width:${(s.n / maxStatus) * 100}%"></i></span><b class="right">${s.n}</b></a>`)}</div></section>
    </div>
    <div class="dash3">
      <section class="card"><h3>Low stock <small>${d.lowStock.length ? "Restock soon" : ""}</small></h3>
        ${d.lowStock.length ? html`<div class="list">${d.lowStock.map((p) => html`<div class="li"><a href="#/products/${p.id}"><b>${p.name}</b><span class="faint" style="display:block;font-size:12px">${p.sku || ""}</span></a><span class="${p.stock_quantity <= 0 ? "stock-out" : "stock-low"}">${p.stock_quantity <= 0 ? "Out of stock" : p.stock_quantity + " left"}</span></div>`)}</div>`
          : html`<p class="muted">Every product is well stocked. 🎉</p>`}</section>
      <section class="card"><h3>Top products <small>By units sold</small></h3>
        ${d.topProducts.length ? html`<div class="list">${d.topProducts.map((p, i) => html`<div class="li"><span><span class="faint">${i + 1}.</span> ${p.name}</span><span class="right nowrap"><b>${p.units}</b> <span class="faint">· ${money(p.revenue)}</span></span></div>`)}</div>` : html`<p class="muted">No sales yet.</p>`}</section>
      <section class="card"><h3>Quick links</h3><div class="list">
        <a class="li" href="#/products?low=1"><span>Low-stock products</span>${ic("right", 16)}</a>
        <a class="li" href="#/orders?guest=1"><span>Guest orders</span>${ic("right", 16)}</a>
        <a class="li" href="#/orders?digital=1"><span>Digital orders</span>${ic("right", 16)}</a>
        <a class="li" href="#/products?availability=preorder"><span>Pre-order products</span>${ic("right", 16)}</a></div></section>
    </div>
    <section class="card flush"><h3 style="padding:20px 20px 0">Recent orders <a class="link" style="font-size:13px;font-weight:500" href="#/orders">See all</a></h3>
      ${d.recentOrders.length ? html`<div class="table-wrap"><table class="cards"><thead><tr><th>Order</th><th>Customer</th><th>Status</th><th>Payment</th><th class="num">Total</th><th>Placed</th></tr></thead><tbody>
        ${d.recentOrders.map((o) => html`<tr><td class="main-cell"><a class="link" href="#/orders/${o.id}">${o.orderNumber}</a></td><td data-l="Customer">${o.customerName}</td><td data-l="Status">${pill(o.status)}</td><td data-l="Payment">${pill(o.paymentStatus)}</td><td class="num" data-l="Total">${money(o.total)}</td><td data-l="Placed" class="nowrap">${fmtDate(o.createdAt)}</td></tr>`)}</tbody></table></div>`
        : html`<div class="empty"><b>No orders yet</b>Orders placed in the store will appear here.</div>`}</section>`);
  bindChart(el, d.series);
}
