// Admin API wrapper. Token lives in localStorage (wrapped: storage can be blocked).
const K = "orivo_admin_token", U = "orivo_admin_user";
const ls = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
  del(k) { try { localStorage.removeItem(k); } catch (e) {} }
};
let mem = { token: null, user: null };
export const getToken = () => ls.get(K) || mem.token;
export const getAdmin = () => { try { return JSON.parse(ls.get(U) || "null") || mem.user; } catch (e) { return mem.user; } };
export function setSession(token, admin) { mem = { token, user: admin }; ls.set(K, token); ls.set(U, JSON.stringify(admin)); }
export function clearSession() { mem = { token: null, user: null }; ls.del(K); ls.del(U); }

let onUnauthorized = () => {};
export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn; };

export class ApiError extends Error {
  constructor(msg, status, code, data) { super(msg); this.status = status; this.code = code; this.data = data; }
}

async function request(path, { method = "GET", body, raw, headers = {}, auth = true } = {}) {
  const h = { ...headers };
  const t = auth ? getToken() : null;
  if (t) h.Authorization = "Bearer " + t;
  let payload;
  if (raw !== undefined) payload = raw;
  else if (body !== undefined) { h["Content-Type"] = "application/json"; payload = JSON.stringify(body); }
  let res;
  try { res = await fetch("/api/admin" + path, { method, headers: h, body: payload }); }
  catch (e) { throw new ApiError("Can't reach the server. Check your connection and try again.", 0, "NETWORK"); }
  let data = {};
  try { data = await res.json(); } catch (e) { /* non-JSON */ }
  if (res.status === 401 && auth && path !== "/login") { clearSession(); onUnauthorized(); }
  if (!res.ok || data.success === false) throw new ApiError(data.message || "Something went wrong. Please try again.", res.status, data.code, data);
  return data;
}

export const api = {
  get: (p) => request(p),
  post: (p, body) => request(p, { method: "POST", body }),
  put: (p, body) => request(p, { method: "PUT", body }),
  patch: (p, body) => request(p, { method: "PATCH", body }),
  del: (p) => request(p, { method: "DELETE" }),
  login: (email, password) => request("/login", { method: "POST", body: { email, password }, auth: false }),
  /** Upload one image file (raw bytes). Returns the public URL. */
  async upload(file) {
    if (file.size > 8 * 1024 * 1024) throw new ApiError(`"${file.name}" is larger than 8 MB`, 400);
    if (!/^image\/(jpeg|png|webp|gif)$/.test(file.type)) throw new ApiError(`"${file.name}" must be a JPG, PNG, WEBP or GIF image`, 400);
    const r = await request("/upload", { method: "POST", raw: file, headers: { "Content-Type": file.type } });
    return r.url;
  }
};

export const qs = (o) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(o)) if (v !== undefined && v !== null && v !== "" && v !== false) p.set(k, v === true ? "1" : v);
  const s = p.toString();
  return s ? "?" + s : "";
};
